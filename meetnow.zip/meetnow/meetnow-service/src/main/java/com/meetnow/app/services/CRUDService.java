/**
 * 
 */
package com.meetnow.app.services;

/**
 * @author ABHILASH
 *
 */
public interface CRUDService {
	<T> void create(T instance);
}
