/**
 * 
 */
package com.meetnow.app.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.meetnow.app.daos.CRUDDao;

/**
 * @author ABHILASH
 *
 */
@Service("coreCRUDService")
@Transactional
public class CoreCRUDService implements CRUDService {

	@Autowired
	@Qualifier("coreCRUDDao")
	private CRUDDao crudDao;
	
	@Override
	public <T> void create(T instance) {
		crudDao.create(instance);
	}

}
