package com.meetnow.app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RestController;

import com.meetnow.app.services.CRUDService;

@RestController
public class BaseController {

	@Autowired
	@Qualifier("coreCRUDService")
	private CRUDService crudService;
	
	protected <T> void create(T instance) {
		crudService.create(instance);
	}
}
