package com.meetnow.app;

import java.time.OffsetDateTime;
import java.time.ZonedDateTime;

public class Test {

	public static void main(String[] args) {
		System.out.println(OffsetDateTime.now().getOffset().getId());
		System.out.println(ZonedDateTime.now().getOffset().getId());
	}
}
