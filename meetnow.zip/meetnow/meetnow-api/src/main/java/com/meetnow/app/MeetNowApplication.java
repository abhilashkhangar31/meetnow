package com.meetnow.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@EntityScan(basePackages = { "com.meetnow" })
@ComponentScan(basePackages = { "com.meetnow" })
@SpringBootApplication
public class MeetNowApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeetNowApplication.class, args);
	}
}
