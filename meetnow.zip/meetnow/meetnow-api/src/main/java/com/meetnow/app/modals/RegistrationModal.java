package com.meetnow.app.modals;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class RegistrationModal {

	@NotBlank
	@Pattern(regexp = "^(?=.{1,40}$)[a-zA-Z]+(?:[-' ][a-zA-Z]+)*$")
	@Min(2)
	@Max(20)
	private String firstName;

	@NotBlank
	@Pattern(regexp = "^(?=.{1,40}$)[a-zA-Z]+(?:[-' ][a-zA-Z]+)*$")
	@Min(2)
	@Max(20)
	private String lastName;

	@NotBlank
	private LocalDate dateOfBirth;

	@Email
	private String emailId;

	@NotBlank
	@DateTimeFormat(iso = ISO.DATE, pattern = "yyyy/MM/dd")
	private String password;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = new BCryptPasswordEncoder().encode(password);
	}

}
