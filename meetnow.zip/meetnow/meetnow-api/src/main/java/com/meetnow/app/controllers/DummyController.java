package com.meetnow.app.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("dummy")
public class DummyController {

	@GetMapping("tryMe")
	protected String tryMe() {
		return "I'm working";
	}
}
