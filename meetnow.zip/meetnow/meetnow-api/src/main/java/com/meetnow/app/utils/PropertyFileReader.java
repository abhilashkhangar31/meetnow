/**
 * 
 */
package com.meetnow.app.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;

/**
 * @author ABHILASH
 *
 */
@PropertySources({ @PropertySource("classpath:bean_validation.properties") })
public class PropertyFileReader {

	@Autowired
	private static Environment env;

	public static String getPropertyValue(String property) {
		if (env.containsProperty(property))
			return env.getProperty(property);
		return null;
	}
}
