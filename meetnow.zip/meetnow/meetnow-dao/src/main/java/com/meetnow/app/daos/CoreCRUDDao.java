/**
 * 
 */
package com.meetnow.app.daos;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @author ABHILASH
 *
 */
@Repository("coreCRUDDao")
public class CoreCRUDDao implements CRUDDao {

	@Autowired
	private EntityManager em;

	@Override
	public <T> void create(T instance) {
		em.persist(instance);
	}

}
