/**
 * 
 */
package com.meetnow.app.pojos;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * <p>
 * Entity to store user personal information. Object of <code>MeetNowUser</code>
 * deals with database.
 * </p>
 * 
 * @author Abhilash Khangar
 * @version <i>v1.0</i>
 * @category Database entity class.
 * @since 21-Jan-2019
 * @see MeetNowUserCredential
 */
@Entity
@Table(name = "MEETNOWUSER")
public class MeetNowUser implements Serializable {

	private static final long serialVersionUID = 949101878159949348L;

	private Long meetNowUserId;
	private String firstName;
	private String lastName;
	private LocalDate dateOfBirth;
	private MeetNowUserCredential meetNowUserCredential;
	private Timestamp creationTime = new Timestamp(new Date().getTime());
	private Timestamp lastModifiedTime = new Timestamp(new Date().getTime());

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "MNU_ID")
	public Long getMeetNowUserId() {
		return meetNowUserId;
	}

	public void setMeetNowUserId(Long meetNowUserId) {
		this.meetNowUserId = meetNowUserId;
	}

	@Column(name = "FIRSTNAME")
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@Column(name = "LASTNAME")
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Column(name = "DOB")
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@OneToOne(mappedBy = "meetNowUser", cascade = CascadeType.PERSIST)
	public MeetNowUserCredential getMeetNowUserCredential() {
		return meetNowUserCredential;
	}

	public void setMeetNowUserCredential(MeetNowUserCredential meetNowUserCredential) {
		this.meetNowUserCredential = meetNowUserCredential;
	}

	@Column(name = "CREATION_TIME")
	public Timestamp getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	@Column(name = "LASTMODIFIED_TIME")
	public Timestamp getLastModifiedTime() {
		return lastModifiedTime;
	}

	public void setLastModifiedTime(Timestamp lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

}
