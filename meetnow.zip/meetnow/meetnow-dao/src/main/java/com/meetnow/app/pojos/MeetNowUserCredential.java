/**
 * 
 */
package com.meetnow.app.pojos;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

/**
 * <p>
 * Entity to store user credentials for authentication purpose.
 * </p>
 * 
 * @author ABHILASH
 * @version <i>v1.0</i>
 * @category Database entity class.
 * @since 21-Jan-2019
 */
@Entity
@Table(name = "MEETNOWUSERCRED")
public class MeetNowUserCredential implements Serializable {

	private static final long serialVersionUID = -2036692020202412585L;

	private Long meetNowUserCredId;
	private String emailId;
	private String password;
	private MeetNowUser meetNowUser;
	private Timestamp creationTime = new Timestamp(new Date().getTime());
	private Timestamp lastModifiedTime = new Timestamp(new Date().getTime());

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "MNUC_ID")
	public Long getMeetNowUserCredId() {
		return meetNowUserCredId;
	}

	public void setMeetNowUserCredId(Long meetNowUserCredId) {
		this.meetNowUserCredId = meetNowUserCredId;
	}

	@Column(name = "EMAILID")
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String userId) {
		this.emailId = userId;
	}

	@Column(name = "PASSWORD")
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@OneToOne
	@PrimaryKeyJoinColumn
	public MeetNowUser getMeetNowUser() {
		return meetNowUser;
	}

	public void setMeetNowUser(MeetNowUser meetNowUser) {
		this.meetNowUser = meetNowUser;
	}

	@Column(name = "CREATION_TIME")
	public Timestamp getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	@Column(name = "LASTMODIFIED_TIME")
	public Timestamp getLastModifiedTime() {
		return lastModifiedTime;
	}

	public void setLastModifiedTime(Timestamp lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

}
