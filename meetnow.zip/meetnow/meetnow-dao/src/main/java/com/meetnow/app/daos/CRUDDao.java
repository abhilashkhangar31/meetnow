package com.meetnow.app.daos;

public interface CRUDDao {
	<T> void create(T instance);
}
